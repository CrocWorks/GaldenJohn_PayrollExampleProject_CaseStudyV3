package com.luv2code.web.jdbc;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;


class JUnitTestEmployee {
		
	private Employee createEmployeeWithWage(float hoursToTest, float payrateToTest) {
		
		//This will check to make sure that pay is payrate*hours up to 40 hours + payrate*hours*1.5 for every hour over 40
		float expectedPay = (float) (Math.min(hoursToTest, 40)*payrateToTest + (Math.max(0, hoursToTest-40))*payrateToTest*1.5);
		
		Employee testEmployee = new Employee("testFirstName", "testLastName", "testEmail", hoursToTest, payrateToTest, expectedPay);
		
		return testEmployee;		
	}
	
	
	@Test
	void testPay50Hours() {

		float hoursToTest = 50F;
		float payrateToTest = 14F;
		
		Employee testPay50HoursEmployee = createEmployeeWithWage(hoursToTest, payrateToTest);
		
		
		//I need this to equal the amount that some created person will have
		//Value should be 770
		Assert.assertTrue( testPay50HoursEmployee.getPay() == 770F);
		
	}


	@Test
	void testPay30Hours() {

		float hoursToTest = 30F;
		float payrateToTest = 14F;
		
		Employee testPay50HoursEmployee = createEmployeeWithWage(hoursToTest, payrateToTest);
		
		
		//I need this to equal the amount that some created person will have
		//Value should be 420
		Assert.assertTrue( testPay50HoursEmployee.getPay() == 420F);
		
	}
	

	
}
