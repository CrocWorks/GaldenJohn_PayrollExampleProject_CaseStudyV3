function validate() {
    if(document.myForm.Name.value == "" ) {
        alert( "Please provide your name!" );
        document.myForm.Name.focus() ;
        return false;
    }
    else{
        var NAME = document.getElementById("NAME").value;
    }
   
    if( document.myForm.EMail.value == "" ) {
        alert( "Please provide your Email!" );
        document.myForm.EMail.focus() ;
        return false;
     }
    if( document.myForm.EMail.value != "" ) {
        if(validateEmail()){
            var emailValue = document.getElementById("emailID").value;
        }    	    
    }
    if(document.myForm.firstName.value == "" ) {
        alert( "Please provide the employee first name!" );
        document.myForm.firstName.focus() ;
        return false;
    }
    if(document.myForm.lastName.value == "" ) {
        alert( "Please provide the employee last name!" );
        document.myForm.lastName.focus() ;
        return false;
    }
	if(document.myForm.email.value == "" ) {
        alert( "Please provide the employee email!" );
        document.myForm.email.focus() ;
        return false;
    }

	if(document.myForm.payrate.value == "" ) {
        alert( "Please provide the employee payrate!" );
        document.myForm.payrate.focus() ;
        return false;
    }

	if(document.myForm.hours.value == "" ) {
        alert( "Please provide the employee hours!" );
        document.myForm.hours.focus() ;
        return false;
    }
	if(document.myForm.pay.value == "" ) {
        alert( "Please provide the employee pay!" );
        document.myForm.pay.focus() ;
        return false;
    }

}


function validateEmail() {
    var emailID = document.myForm.EMail.value;
    atpos = emailID.indexOf("@");
    //alert(atpos)
    dotpos = emailID.lastIndexOf(".");
    if (atpos < 1 || ( dotpos - atpos < 2 )) {
        alert("Please enter correct email ID")
        document.myForm.EMail.focus() ;
        return false;
    }
    else{
        return true;
    }
    return( true )
}
